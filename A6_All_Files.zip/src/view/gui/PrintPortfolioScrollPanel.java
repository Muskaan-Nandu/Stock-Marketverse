package view.gui;

import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

class PrintPortfolioScrollPanel {

  private JScrollPane scrollPanel;
  private JFrame frame;

  private JPanel mainPanel;

  public PrintPortfolioScrollPanel(JFrame frame, JTable jtable) {
    this.frame = frame;
    mainPanel = new JPanel();
    mainPanel.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10,
            10, 10), new EtchedBorder()));

    scrollPanel = new JScrollPane(jtable, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scrollPanel.setPreferredSize(new Dimension(200, 300));

    mainPanel.add(scrollPanel);
  }

  public void setPanel() {
    frame.add(mainPanel);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.remove(scrollPanel);
  }
}
