package view.gui;

import javax.swing.JPanel;
import javax.swing.JLabel;

class HeadingPanel {

  private final JPanel frame;
  private JPanel headingPanel;

  MyColors colors;

  public HeadingPanel(JPanel frame, String str) {
    this.frame = frame;
    headingPanel = new JPanel();

    colors = new MyColors();
    headingPanel.setBackground(colors.panecol);

    JLabel title = new JLabel("<html><h2 style = 'color: #2980B9'>" + str + "</h2></html>");

    headingPanel.add(title);
  }

  public void setPanel() {
    frame.add(headingPanel);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.removeAll();
  }

}
