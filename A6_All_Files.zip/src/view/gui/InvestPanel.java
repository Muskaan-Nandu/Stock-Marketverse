package view.gui;

import java.awt.FlowLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

class InvestPanel {

  private JPanel frame;
  private final JPanel investPanel;
  private JTextField investVal;
  MyColors colors;

  public InvestPanel(JPanel frame) {
    this.frame = frame;
    investPanel = new JPanel();
    investPanel.setLayout(new FlowLayout());
    JLabel enterInvestVal = new JLabel("Enter Investment Value: $");
    investVal = new JTextField(5);
    investVal.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent ke) {
        if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' || ke.getKeyCode()
                == KeyEvent.VK_BACK_SPACE || ke.getKeyChar() <= '.') {
          investVal.setEditable(true);
        } else {
          Error er = new Error();
          er.showError(" Only numeric values allowed!");
          investVal.setText("");
        }
      }
    });
    investPanel.add(enterInvestVal);
    investPanel.add(investVal);
  }

  public void setPanel() {
    frame.add(investPanel);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.removeAll();
  }

  public String getInvestVal() {
    return investVal.getText();
  }

  public void reset() {
    investVal.setText("");
  }
}
