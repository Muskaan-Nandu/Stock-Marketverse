package view.gui;


import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import java.awt.FlowLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

class CommissionFee {

  private JPanel frame;
  private JPanel commissionFeePanel;
  private JTextField commission;
  MyColors colors;

  public CommissionFee(JPanel frame) {
    this.frame = frame;
    commissionFeePanel = new JPanel();
    commissionFeePanel.setLayout(new FlowLayout());
    //    commissionFeePanel.setBackground(colors.panecol);
    JLabel enterCF = new JLabel("Enter Commission Fee: $");
    commission = new JTextField(5);
    commission.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent ke) {
        if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' || ke.getKeyCode()
                == KeyEvent.VK_BACK_SPACE) {
          commission.setEditable(true);
        } else {
          Error er = new Error();
          er.showError(" Only numeric values allowed!");
          commission.setText("");
        }
      }
    });
    commissionFeePanel.add(enterCF);
    commissionFeePanel.add(commission);
  }

  public void setPanel() {
    frame.add(commissionFeePanel);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.removeAll();
  }

  public String getCommission() {
    return commission.getText();
  }

  public void reset() {
    commission.setText("");
  }
}
