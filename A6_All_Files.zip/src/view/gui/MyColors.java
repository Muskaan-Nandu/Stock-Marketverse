package view.gui;

import java.awt.Color;

class MyColors {

  public final Color bgcol;
  public final Color panecol;

  public MyColors() {
    bgcol = new Color(0xAED6F1);
    panecol = new Color(0xEAEDED);
  }
}
