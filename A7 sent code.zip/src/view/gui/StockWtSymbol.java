package view.gui;

import java.awt.FlowLayout;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextArea;

class StockWtSymbol {

  private JPanel frame;
  private JPanel stockWtPanel;
  private JTextArea stockWt;

  public StockWtSymbol(JPanel frame) {
    this.frame = frame;
    stockWtPanel = new JPanel();
    stockWtPanel.setLayout(new FlowLayout());
    JLabel stockWtLabel = new JLabel("Enter Stocks and their Weights:");
    stockWt = new JTextArea(4, 30);
    stockWtPanel.add(stockWtLabel);
    stockWtPanel.add(stockWt);
  }

  public void setPanel() {
    frame.add(stockWtPanel);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.removeAll();
  }

  public String getStockWt() {
    return stockWt.getText();
  }

  public void reset() {
    stockWt.setText("");
  }
}
