package view.gui;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Color;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;

import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

class PrintBarChart {
  private JFrame frame;

  private JPanel mainPanel;

  MyColors colors;

  ChartPanel chartPanel;

  public PrintBarChart(JFrame frame, String startDate, String endDate, String portfolioName,
                       List<String> xaxis, List<Integer> yaxis, double scale) {
    this.frame = frame;
    mainPanel = new JPanel();
    colors = new MyColors();
    mainPanel.setBackground(colors.bgcol);
    mainPanel.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10,
            10, 10), new EtchedBorder()));


    DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    String legend = "portfolio-value";
    for (int i = 0; i < xaxis.size(); i++) {
      dataset.addValue(yaxis.get(i) * scale, legend, xaxis.get(i));
    }

    JFreeChart barChart = ChartFactory.createBarChart("Performance of portfolio "
                    + portfolioName + " from " + startDate + " to " +
                    endDate, "Duration", "Value in Dollars ($)",
            dataset,
            PlotOrientation.HORIZONTAL,
            true, true, false);

    CategoryPlot plot = barChart.getCategoryPlot();
    plot.getRenderer().setSeriesPaint(0, new Color(0x005B96));

    chartPanel = new ChartPanel(barChart);
    chartPanel.setPreferredSize(new Dimension(650, 450));
    JScrollPane scrollPane = new JScrollPane(chartPanel);
    mainPanel.add(scrollPane);
  }

  public void setPanel() {
    frame.add(mainPanel, BorderLayout.CENTER);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.removeAll();
  }

}
