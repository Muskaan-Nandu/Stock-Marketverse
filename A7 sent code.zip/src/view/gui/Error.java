package view.gui;

import javax.swing.JOptionPane;

class Error {

  public Error() {
    // nothing to set
  }

  public void showError(String s) {
    JOptionPane.showMessageDialog(null, s, "An Error Occurred!",
            JOptionPane.ERROR_MESSAGE);
  }
}
