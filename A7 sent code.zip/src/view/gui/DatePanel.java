package view.gui;


import java.awt.FlowLayout;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JLabel;

class DatePanel {

  public JComboBox<String> yearComboBox;
  public JComboBox<String> monthComboBox;
  public JComboBox<String> dayComboBox;

  MyColors colors;
  private JPanel frame;
  private JPanel datePanel;

  public DatePanel(JPanel frame, String var, int year) {

    this.frame = frame;
    colors = new MyColors();

    datePanel = new JPanel();
    datePanel.setLayout(new FlowLayout());
    datePanel.setBackground(colors.panecol);
    JLabel enterDate = new JLabel("Select " + var);
    //new JLabel("Select the date at which you wish to get the value of the portfolio:");
    datePanel.add(enterDate);

    JLabel ddLabel = new JLabel("dd: ");
    datePanel.add(ddLabel);

    dayComboBox = new JComboBox<String>();
    for (int i = 1; i < 32; i++) {
      if (i >= 10) {
        dayComboBox.addItem(i + "");
      } else {
        dayComboBox.addItem("0" + i);
      }
    }
    datePanel.add(dayComboBox);

    JLabel mmLabel = new JLabel("mm: ");
    datePanel.add(mmLabel);

    monthComboBox = new JComboBox<String>();
    for (int i = 1; i < 13; i++) {
      if (i >= 10) {
        monthComboBox.addItem(i + "");
      } else {
        monthComboBox.addItem("0" + i);
      }
    }
    datePanel.add(monthComboBox);

    JLabel yyyyLabel = new JLabel("yyyy: ");
    datePanel.add(yyyyLabel);

    yearComboBox = new JComboBox<String>();
    for (int i = year; i > 1940; i--) {
      yearComboBox.addItem(i + "");
    }
    datePanel.add(yearComboBox);
  }

  public void setPanel() {
    frame.add(datePanel);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.remove(datePanel);
  }

  public void reset() {
    dayComboBox.setSelectedItem(null);
    yearComboBox.setSelectedItem(null);
    monthComboBox.setSelectedItem(null);
  }
}
