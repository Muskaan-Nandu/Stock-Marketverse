package view.gui;

import java.awt.FlowLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

class QtyStock {

  private JPanel frame;

  private JPanel qtyPanel;
  private JTextField qtyVal;
  MyColors colors;

  public QtyStock(JPanel frame) {
    this.frame = frame;
    qtyPanel = new JPanel();
    qtyPanel.setLayout(new FlowLayout());
    colors = new MyColors();
    qtyPanel.setBackground(colors.panecol);
    JLabel qtyLabel = new JLabel("Enter quantity: ");
    qtyVal = new JTextField(10);

    qtyVal.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent ke) {
        if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' || ke.getKeyCode()
                == KeyEvent.VK_BACK_SPACE) {
          qtyVal.setEditable(true);
        } else {
          Error er = new Error();
          er.showError(" Only numeric values allowed!");
          qtyVal.setText("");
        }
      }
    });
    qtyPanel.add(qtyLabel);
    qtyPanel.add(qtyVal);
  }

  public void setPanel() {
    frame.add(qtyPanel);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.removeAll();
  }

  public String getQty() {
    return qtyVal.getText();
  }

  public void reset() {
    qtyVal.setText("");
  }
}
