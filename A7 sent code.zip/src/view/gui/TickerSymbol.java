package view.gui;

import java.awt.FlowLayout;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

class TickerSymbol {

  private JPanel frame;

  private JPanel tickerPanel;
  private JTextField tickerInput;
  MyColors colors;

  public TickerSymbol(JPanel frame) {
    this.frame = frame;
    tickerPanel = new JPanel();
    tickerPanel.setLayout(new FlowLayout());
    colors = new MyColors();
    tickerPanel.setBackground(colors.panecol);
    JLabel tickerLabel = new JLabel("Enter the ticker symbol: ");
    tickerInput = new JTextField(10);
    tickerPanel.add(tickerLabel);
    tickerPanel.add(tickerInput);
  }

  public void setPanel() {
    frame.add(tickerPanel);
    frame.setVisible(true);
  }

  public void removePanel() {
    frame.removeAll();
  }

  public String getTicker() {
    return tickerInput.getText();
  }

  public void reset() {
    tickerInput.setText("");
  }
}
